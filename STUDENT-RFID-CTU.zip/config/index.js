var options = require("./options");

module.exports = {
    getOptionsVal: () => {
        return options;
    }
}