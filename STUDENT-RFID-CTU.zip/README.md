Cài nodemon global:

$> npm i -g nodemon

Chỉnh sửa back-end phải bằng server node:

$> npm start

Chỉnh sửa font-end phải bằng server của angular:

$> ng serve --ssl

Cài Mongodb: https://www.mongodb.com/dr/fastdl.mongodb.org/win32/mongodb-win32-x86_64-2008plus-ssl-3.4.7-signed.msi/download