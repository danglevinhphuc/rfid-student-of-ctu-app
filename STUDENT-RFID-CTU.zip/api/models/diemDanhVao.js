// Tao model diem danh
'use strict';
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var diemDanhVaoSchema = new Schema({
    rfid: {
        type: String,
        required: true
    },
    MSSV: String,
    MSCB: String,
    diemDanhVao: {
        type: date,
        default: Date.now
    }
});

diemDanhVaoSchema.path("MSSV").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
diemDanhVaoSchema.path("MSCB").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
module.exports = mongoose.model('diemDanhVao',diemDanhVaoSchema);