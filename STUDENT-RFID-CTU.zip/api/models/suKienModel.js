// Tao model Sự kiện
'use strict';
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var suKienSchema = new Schema({
    tenSuKien: {
        type: String,
        required: true
    },
    ngay:  {
        type: date,
        required: true
    }
});

suKienSchema.path("hoTen").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
suKienSchema.path("donVi").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
suKienSchema.path("MSCB").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
module.exports = mongoose.model('suKien',suKienSchema);