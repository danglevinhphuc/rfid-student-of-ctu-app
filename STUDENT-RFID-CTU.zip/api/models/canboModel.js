// Tao model Can Bo
'use strict';
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var canBoSchema = new Schema({
    rfid: {
        type: String,
        required: true
    },
    MSCB:  {
        type: String,
        required: true
    },
    hoTen: String,
    email: String,
    donVi: String
});

canBoSchema.path("hoTen").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
canBoSchema.path("donVi").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
canBoSchema.path("MSCB").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
module.exports = mongoose.model('canBo',canBoSchema);