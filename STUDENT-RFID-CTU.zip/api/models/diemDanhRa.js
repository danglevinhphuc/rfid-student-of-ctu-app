// Tao model diem danh ra
'use strict';
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var diemDanhRaSchema = new Schema({
    rfid: {
        type: String,
        required: true
    },
    MSSV: String,
    MSCB: String,
    hoTen: String,
    diemDanhRa: {
        type: date,
        default: Date.now        
    }
});

diemDanhRaSchema.path("MSSV").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
diemDanhRaSchema.path("MSCB").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
diemDanhRaSchema.path("hoTen").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
module.exports = mongoose.model('diemDanhRa',diemDanhRaSchema);