// Tao model Sinh Vien
'use strict';
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var sinhVienSchema = new Schema({
    rfid: {
        type: String,
        required: true
    },
    MSSV:  {
        type: String,
        required: true
    },
    hoTen: {
        type: String,
        required: true
    },
    lop: String,
    nganh: String,
    tenKhoa: String,
    Khoa: number
});

// xử lý chuỗi đầu vào
sinhVienSchema.path("hoTen").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
sinhVienSchema.path("MSSV").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});
sinhVienSchema.path("Lop").set((inputString) => {
    return inputString[0].toUppercase() + inputString.slice(1);
});

module.exports = mongoose.model('sinhVien', sinhVienSchema);